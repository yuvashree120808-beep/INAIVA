# INAIVA technical design

## Current prototype
- **Frontend:** React 18, TypeScript, Vite
- **UI:** responsive CSS and Lucide icons
- **State:** React component state; no persistence
- **Tests:** Vitest unit tests for pricing and profit helpers

## Main user flows
1. Overview → inspect income, expense, and net profit summaries.
2. Add transaction → select income/expense, enter description and amount, save.
3. Transactions → search and review recorded entries.
4. Price calculator → enter unit cost and target margin to estimate selling price.
5. Marketplace / SHG members → view illustrative demo listings and member records.

## Production architecture recommendations
- Identity: secure authentication and SHG-scoped roles (member, treasurer, group admin).
- API: validate all input server-side and enforce tenant/group authorization.
- Data: persist transactions with immutable audit events, timestamps, currency, actor, and SHG ID.
- Privacy: collect minimal member data, document consent and retention, provide export/deletion workflows.
- Localization: use translation dictionaries and test Tamil and English layouts.
- Quality: automated unit, integration, accessibility, and end-to-end tests; backups and monitoring.
